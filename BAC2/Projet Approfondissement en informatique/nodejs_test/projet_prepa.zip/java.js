var express = require('express');
var consolidate = require('consolidate');
var app = express ()


app.engine ( 'html', consolidate.hogan );
app.set('views', 'priv');

app.get('/display',function(req,res){
  res.render('page1.html',{utilisateur:req.query.utilisateur})
});

app.get('/lien',function(req,res){
  res.render('page2.html',{Lien_pour_ajouter_un_incident: req.query.q="Lien pour ajouter un incident"});
});

app.get('/ident',function(req,res){
  res.render('nCompte.html',{Nouveau_Compte: req.query.q="Nouveau_Compte"});
})

app.use(express.static('static'));
app.listen(80);