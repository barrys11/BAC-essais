var express = require('express');
var consolidate = require('consolidate');
var session = require('express-session');//pas completer

MongoClient = require('mongodb').MongoClient;
Server = require('mongodb').Server;

var app = express ()

var bodyParser = require("body-parser");//pas completer
var https = require('https');//pas completer
const cons = require('consolidate');

app.engine ( 'html', consolidate.hogan );
app.set('views', 'priv');

app.use(bodyParser.urlencoded({ extended: true })); 
app.use(session({
  secret: "propre123",
  resave: false,
  saveUninitialized: true,
  cookie: { 
    path: '/', 
    httpOnly: true, 
    maxAge: 3600000
  }
}));

const date=new Date();
const d=date.getDate()+'/'+date.getMonth()+'/'+date.getFullYear();
//connection avec le serveur

MongoClient.connect("mongodb://localhost:27017",function(err, db){
  dbm = db.db('incidents');
  if (err) throw err;
  app.post('/display',function(req,res){//verifications du nom d'utilisateur et mots de passe.
    dbm.collection('utilisateurs').findOne({"utilisateur":req.body.utilisateur,"mot_de_passe":req.body.mot_de_passe},(err,doc) => {
      if (err) throw err;
      else if(doc!=null){
        //res.render('page1.html',{utilisateur:req.query.utilisateur});
        //acceder a la base de donner si l'utilisateur et le mot de passe est correcte.
        req.session.utilisateur=req.body.utilisateur; //ajouter un cookie
        dbm.collection('incidents').find({}).toArray((err, doc) =>{
          if (err) throw err;
          res.render('page1.html', {data: doc,utilisateur:req.session.utilisateur});
        });
      }else{
        res.render('../static/index.html');}
    });
  })
  
  app.get('/lien',function(req,res){//lien vers la page pour ajouter des incidents.
    res.render('page2.html',{Lien_pour_ajouter_un_incident: req.query.q="Lien pour ajouter un incident",utilisateur:req.session.utilisateur});
  });
  

  app.get('/des',function(req,res){ // ajouter les donnez dans la db.
    dbm.collection("incidents").insertOne({"incident":req.query.incident,"adresse":req.query.adresse,"date":d}, function(err, doc){
      if(err) throw err;
      dbm.collection('incidents').find({}).toArray((err, doc) =>{
        if (err) throw err;
          res.render('page1.html', {data: doc,utilisateur:req.session.utilisateur});
        });
    });
    //res.render('page1.html',{description:req.query.description,adresse:req.query.adresse})
  })
  
  app.get('/ident',function(req,res){//ajouter un nouveau utilisateur.
    res.render('nCompte.html',{Nouveau_Compte: req.query.q="Nouveau_Compte"});
  });

  app.get('/enregistre',function(req,res){//ajouter un utilisateur dans la base.
    dbm.collection('utilisateurs').findOne({"utilisateur":req.query.utilisateur},(err,doc)=>{
      if (err) throw err;
      else if (doc!=null){
        res.render('nCompte.html',{utilisateur:"Le nom d'utilisateur existe"})//ne fonctionne pas a corrigé.
      }else{
        dbm.collection('utilisateurs').insertOne({"utilisateur":req.query.utilisateur,"mot_de_passe":req.query.mot_de_passe,"nom":req.query.nom,"prenom":req.query.prenom,"mail":req.query.mail});
        req.session.utilisateur=req.query.utilisateur;//ajouter un cookie
        dbm.collection('incidents').find({}).toArray((err, doc) =>{
          if (err) throw err;
          res.render('page1.html', {data: doc,utilisateur:req.session.utilisateur});
        });
      }
    })
  })
});

app.use(express.static('static'));

app.listen(80);