Pour lancer le serveur , il faut:
- Dezipper le fichier .zip et récuperer le dossier qui se nomme projet_preparatoire
- Ouvrir son invite de commande
- Se placer dans le dossier où se trouve le fichier javascript c'est à dire le dossier projet_preparatoire
- Faire la commande suivante : mongod --dbpath mongodb_test
- Faire la commande suivante : node java.js puis appuyer sur entrer
-Mettre sur le navigateur:
	https://localhost:80


Au choix:
-pour afficher des element dans la base au debut vous pouvez mettre mongoimport -d incidents -c incidents dbmongo/database.json

